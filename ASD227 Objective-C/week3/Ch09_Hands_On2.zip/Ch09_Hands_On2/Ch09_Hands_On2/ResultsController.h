//
//  ResultsController.h
//  Ch09_Hands_On2
//
//  Created by user168240 on 1/22/21.
//  Copyright © 2021 user168240. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ResultsController : NSObject
@property (retain, nonatomic) IBOutlet UILabel *result;
@property (nonatomic, strong) NSString *calculatedResult;

@end

NS_ASSUME_NONNULL_END
