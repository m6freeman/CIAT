//
//  ViewController.h
//  Ch09_Hands_On2
//
//  Created by user168240 on 1/22/21.
//  Copyright © 2021 user168240. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *height;
@property (weak, nonatomic) IBOutlet UITextField *weight;
@property (weak, nonatomic) IBOutlet UISegmentedControl *measure;
@property (weak, nonatomic) IBOutlet UISwitch *male;
- (IBAction)maleSelected:(id)sender;
@property (weak, nonatomic) IBOutlet UISwitch *female;
- (IBAction)femaleSelected:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *resetButton;

- (IBAction)hideKeyboard:(id)sender;

@end

