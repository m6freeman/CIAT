//
//  ResultsController.m
//  Ch09_Hands_On2
//
//  Created by user168240 on 1/22/21.
//  Copyright © 2021 user168240. All rights reserved.
//

#import "ResultsController.h"

@implementation ResultsController
@synthesize result, calculatedResult;
- (void)viewDidLoad
{
    [result setText:calculatedResult];
}
@end
