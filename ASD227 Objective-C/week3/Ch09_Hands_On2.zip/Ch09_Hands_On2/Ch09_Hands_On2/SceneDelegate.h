//
//  SceneDelegate.h
//  Ch09_Hands_On2
//
//  Created by user168240 on 1/22/21.
//  Copyright © 2021 user168240. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

