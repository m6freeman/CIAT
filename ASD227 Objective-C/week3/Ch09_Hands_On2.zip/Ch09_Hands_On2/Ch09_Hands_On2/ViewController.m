//
//  ViewController.m
//  Ch09_Hands_On2
//
//  Created by user168240 on 1/22/21.
//  Copyright © 2021 user168240. All rights reserved.
//

#import "ViewController.h"
#import "ResultsController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize male, female, measure, height, weight;

- (void)viewDidLoad
{
    [super viewDidLoad];
    male.on = NO;
    female.on = YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    double result = [weight.text doubleValue]/([height.text doubleValue] * [height.text doubleValue]);
    if (measure.selectedSegmentIndex == 0)
    {
        if (male.isOn)
        {
            result *= 703;
        }
        else
        {
            result *= 703;
        }
    }
    else
    {
        
    }
    if ([segue.identifier isEqualToString: @"sendData"])
    {
        ResultsController *resultController = segue.destinationViewController;
        resultController.calculatedResult = [NSString stringWithFormat:@"%.2f", result];
    }
}


- (IBAction)maleSelected:(id)sender
{
    if (male.on)
    {
        [female setOn:NO];
    }
    else
    {
        [female setOn:YES];
    }
}
- (IBAction)femaleSelected:(id)sender
{
    if (female.on)
    {
        [male setOn:NO];
    }
    else
    {
        [male setOn:YES];
    }
}

- (IBAction)_resetButton:(id)sender
{
    [height setText:@""];
    [weight setText:@""];
    [measure setSelectedSegmentIndex:0];
    [male setOn:NO];
    [female setOn:YES];
}

- (IBAction)hideKeyboard:(id)sender
{
    [sender resignFirstResponder];
}
@end
