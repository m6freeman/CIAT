namespace chapterTwoProjectTwo
{
    public enum DistanceUnits
    {
        FEET,
        KILOMETERS,
        MILES
    }
}