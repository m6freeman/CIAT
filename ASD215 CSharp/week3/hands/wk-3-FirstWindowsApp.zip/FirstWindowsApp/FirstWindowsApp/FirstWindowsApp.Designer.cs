﻿namespace FirstWindowsApp
{
    partial class FirstWindowsApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.lblName = new System.Windows.Forms.Label();
			this.txtBxName = new System.Windows.Forms.TextBox();
			this.btnOk = new System.Windows.Forms.Button();
			this.lblAnswer = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblName
			// 
			this.lblName.AutoSize = true;
			this.lblName.Location = new System.Drawing.Point(151, 74);
			this.lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(66, 24);
			this.lblName.TabIndex = 0;
			this.lblName.Text = "Name:";
			// 
			// txtBxName
			// 
			this.txtBxName.Location = new System.Drawing.Point(227, 77);
			this.txtBxName.Name = "txtBxName";
			this.txtBxName.Size = new System.Drawing.Size(207, 29);
			this.txtBxName.TabIndex = 1;
			// 
			// btnOk
			// 
			this.btnOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.btnOk.ForeColor = System.Drawing.Color.Blue;
			this.btnOk.Location = new System.Drawing.Point(244, 219);
			this.btnOk.Name = "btnOk";
			this.btnOk.Size = new System.Drawing.Size(97, 46);
			this.btnOk.TabIndex = 2;
			this.btnOk.Text = "Submit";
			this.btnOk.UseVisualStyleBackColor = true;
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// lblAnswer
			// 
			this.lblAnswer.AutoSize = true;
			this.lblAnswer.Location = new System.Drawing.Point(52, 333);
			this.lblAnswer.Name = "lblAnswer";
			this.lblAnswer.Size = new System.Drawing.Size(0, 24);
			this.lblAnswer.TabIndex = 3;
			// 
			// FirstWindowsApp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Blue;
			this.ClientSize = new System.Drawing.Size(585, 484);
			this.Controls.Add(this.lblAnswer);
			this.Controls.Add(this.btnOk);
			this.Controls.Add(this.txtBxName);
			this.Controls.Add(this.lblName);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.Margin = new System.Windows.Forms.Padding(6);
			this.Name = "FirstWindowsApp";
			this.Text = "Name Retrieval App";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtBxName;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label lblAnswer;
    }
}

