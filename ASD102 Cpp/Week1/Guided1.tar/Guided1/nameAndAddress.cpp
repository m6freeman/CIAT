#include <iostream>

using namespace std;
int main(void)
{
    cout << "Matt Freeman" << endl;
    cout << "123 Main St." << endl;
    cout << "San Diego, CA";
    return 0;
}
