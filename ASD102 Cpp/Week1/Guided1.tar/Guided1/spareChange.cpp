#include <iostream>

using namespace std;
int main(void)
{
    double money = 4.36;
    cout << "In my pocket, I have $" << money << endl;
    return 0;
}