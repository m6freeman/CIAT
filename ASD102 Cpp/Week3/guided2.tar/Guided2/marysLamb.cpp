#include <iostream>
#include <string>

using namespace std;

string marysLamb();

int main(void)
{
    cout << marysLamb() << endl;
    return 0;
}


string marysLamb() 
{
    return "Mary had a little lamb whose fleece was pretty badly matted. It would go to places with her, like the pharmacy. ";
}