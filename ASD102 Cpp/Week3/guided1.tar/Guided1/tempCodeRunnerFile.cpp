    // switch (meals)
    // {
    // case 1 ... 10:
    //     cout << meals * 14.99 << endl;
    //     break;

    // case 11 ... 20:
    //     cout << meals * 12.50 << endl;
    //     break;

    // case 21 ... 39:
    //     cout << meals * 10.75 << endl;
    //     break;
    
    // default:
    //     cout << meals * 9.45 << endl;
    //     break;
    // }